package com.example.petmatch_perfil

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@Composable
fun PetMatchWelcomeScreen(
    onEnterClick: () -> Unit,
    onDesenvolvedorasClick: () -> Unit
) {
    val backgroundColor = Color(0xFFFDF1E3)
    val iconBackground = Color(0xFF5C4433)
    val buttonColor = Color(0xFFB55D45)

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = backgroundColor
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Logo PetMatch",
                modifier = Modifier
                    .size(200.dp)
                    .clip(CircleShape)
            )

            Text(
                text = "Bem Vindo !",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Favorite,
                        contentDescription = "Instagram",
                        tint = Color.White,
                        modifier = Modifier
                            .background(iconBackground, shape = CircleShape)
                            .padding(8.dp)
                            .size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "@petMatch",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Email,
                        contentDescription = "Email",
                        tint = Color.White,
                        modifier = Modifier
                            .background(iconBackground, shape = CircleShape)
                            .padding(8.dp)
                            .size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "petmatch@gmail.com",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Botão Entrar
            Button(
                onClick = onEnterClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = buttonColor,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .width(150.dp)
                    .height(50.dp)
            ) {
                Text(text = "Entrar", fontWeight = FontWeight.Bold)
            }

            // Botão Desenvolvedoras
            Button(
                onClick = onDesenvolvedorasClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = buttonColor,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .width(160.dp)
                    .height(50.dp)
            ) {
                Text(text = "Desenvolvedoras", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PetMatchWelcomeScreenPreview() {
    PetMatchWelcomeScreen(
        onEnterClick = {},
        onDesenvolvedorasClick = {}
    )
}

@Composable
fun WelcomeScreenWrapper(navController: NavHostController) {
    PetMatchWelcomeScreen(
        onEnterClick = { navController.navigate("catalogo") },
        onDesenvolvedorasClick = { navController.navigate("nomes") }
    )
}

