import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.petmatch_perfil.R

@Composable
fun IntegrantesComPlaquinhaScreen(onBackClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F0E1)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Desenvolvedoras do projeto!",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.padding(top = 40.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.cachorroplaca),
                contentDescription = "Cachorrinho segurando plaquinha",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(750.dp),
                contentScale = ContentScale.Fit
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 165.dp)
            ) {
                val integrantes = listOf(
                    "Bruna Ferreira - 2401556",
                    "Giovana Lopes - 2401570",
                    "Lavínia Braga - 2400789",
                    "Letícia Policeno - 2400972"
                )

                integrantes.forEach { integrante ->
                    Text(
                        text = integrante,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }

        // Botão Voltar para Home
        Button(
            onClick = onBackClick,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFB55D45),
                contentColor = Color.White
            ),
            modifier = Modifier
                .padding(bottom = 35.dp)
                .width(200.dp)
                .height(50.dp)
        ) {
            Text("Voltar", fontWeight = FontWeight.Bold)
        }
    }
}


@Composable
fun IntegrantesComPlaquinha(navController: NavController) {
    IntegrantesComPlaquinhaScreen {
        navController.navigate("home")
    }
}

@Preview(showBackground = true)
@Composable
fun IntegrantesComPlaquinhaPreview() {
    IntegrantesComPlaquinhaScreen(onBackClick = {})
}
