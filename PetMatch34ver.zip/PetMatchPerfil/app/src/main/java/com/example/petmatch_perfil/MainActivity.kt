package com.example.petmatch_perfil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.rememberNavController
import com.example.petmatch_perfil.ui.theme.PetMatchPerfilTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PetMatchPerfilTheme {
                val navController = rememberNavController()
                Column {
                    AppNavGraph(navController = navController)
                    BottomNavigationBar { route ->
                        navController.navigate(route)
                    }
                }
            }
        }
    }
}

@Composable
fun BottomNavigationBar(onItemSelected: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .background(Color(0xFF4D3A32))
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(id = R.drawable.baseline_pets_24),
            contentDescription = "Catálogo",
            tint = Color(0xFFEAC29A),
            modifier = Modifier
                .size(24.dp)
                .clickable { onItemSelected("catalogo") }
        )
        Icon(
            imageVector = Icons.Default.Place,
            contentDescription = "Locais",
            tint = Color(0xFFEAC29A),
            modifier = Modifier
                .size(24.dp)
                .clickable { onItemSelected("locais") }
        )
        Icon(
            imageVector = Icons.Default.Person,
            contentDescription = "Perfil",
            tint = Color(0xFFEAC29A),
            modifier = Modifier
                .size(24.dp)
                .clickable { onItemSelected("perfil") }
        )
        Icon(
            painter = painterResource(id = R.drawable.baseline_add_home_24), // Ícone de home
            contentDescription = "Início",
            tint = Color(0xFFEAC29A),
            modifier = Modifier
                .size(24.dp)
                .clickable { onItemSelected("home") }
        )
    }
}

@Preview(showBackground = true)
@Composable
fun BottomNavigationBarPreview() {
    BottomNavigationBar(onItemSelected = {})
}
