package com.example.petmatch_perfil

import IntegrantesComPlaquinha
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.petmatch_perfil.CatalogoScreen
import com.example.petmatch_perfil.LocaisAdocaoScreen
import com.example.petmatch_perfil.PerfilScreen

@Composable
fun AppNavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "home") {
        composable("home") { WelcomeScreenWrapper(navController) }
        composable("catalogo") { CatalogoScreen(onNavigate = { navController.navigate(it) }) }
        composable("locais") { LocaisAdocaoScreen(navController) }
        composable("perfil") { PerfilScreenWrapper(navController) }
        composable("nomes") { IntegrantesComPlaquinha(navController) }

    }
}


